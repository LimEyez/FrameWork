class UI3DComponent extends Component {
    constructor(options) {
        super(options);
        this.color = document.getElementById('Color3D');
    }

    _addEventListeners() {
        document.getElementById('showHide3D').addEventListener('click', this.showHide);
        
        document.getElementById('sphere').addEventListener('click', () => {
            console.log(typeof(this.color.value))
            this.callbacks.CreateFigure(`(new figure).Sphere(10, 20, '${this.color.value}');`);
        });
        document.getElementById('cube').addEventListener('click', () => {
            this.callbacks.CreateFigure(`(new figure).Cube('${this.color.value}');`);
        });
        document.getElementById('torus').addEventListener('click', () => {
            this.callbacks.CreateFigure(`(new figure).Tor(10, 5, 21, '${this.color.value}');`);
        });
        document.getElementById('cone').addEventListener('click', () => {
            this.callbacks.CreateFigure(`(new figure).Cone(4, 4, 4, 10, '${this.color.value}');`);
        });
        document.getElementById('ellipsoid').addEventListener('click', () => {
            this.callbacks.CreateFigure(`(new figure).Ellipsoid(10, 15, 20, 20, '${this.color.value}');`);
        });
        document.getElementById('hyperboloid1').addEventListener('click', () => {
            this.callbacks.CreateFigure(`(new figure).Hyperboloid1(1, 1, 1, 20, '${this.color.value}');`);
        });
        document.getElementById('hyperboloid2').addEventListener('click', () => {
            this.callbacks.CreateFigure(`(new figure).Hyperboloid2(-1, 1, 1, 20, '${this.color.value}');`);
        });
        document.getElementById('ellipticalCylinder').addEventListener('click', () => {
            this.callbacks.CreateFigure(`(new figure).EllipticalCylinder(10, 10, 10, 20, '${this.color.value}');`);
        });
        document.getElementById('hyperbolicCylinder').addEventListener('click', () => {
            this.callbacks.CreateFigure(`(new figure).HyperbolicCylinder(0.5, 1, 3, 10, '${this.color.value}');`);
        });
        document.getElementById('parabolicCylinder').addEventListener('click', () => {
            this.callbacks.CreateFigure(`(new figure).ParabolicCylinder(10, 8, 20, '${this.color.value}');`);
        });
        document.getElementById('ellipticalParaboloid').addEventListener('click', () => {
            this.callbacks.CreateFigure(`(new figure).EllipticalParaboloid(7, 10, 0.5, 20, '${this.color.value}');`);
        });
        document.getElementById('hyperbolicParaboloid').addEventListener('click', () => {
            this.callbacks.CreateFigure(`(new figure).HyperbolicParaboloid(20, 10, 10, 20, '${this.color.value}');`);
        });
    };

    showHide() {
        document.querySelector('.overlay3D').classList.toggle('hide');
    };

}
