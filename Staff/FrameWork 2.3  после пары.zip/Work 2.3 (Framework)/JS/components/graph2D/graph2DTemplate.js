Template.prototype.graph2DTemplate = () => `
    <div class="opo" id = 'opo'>
        <canvas id="canvas"></canvas>
    </div>
        `;