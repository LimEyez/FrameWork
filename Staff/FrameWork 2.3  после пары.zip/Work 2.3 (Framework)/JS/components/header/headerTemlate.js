Template.prototype.headerTemplate = () => `
    <button class="showPage" data-component="graph2D">Графика 2D</button>
    <button class="showPage" data-component="calculator">Калькулятор</button>
    <button class="showPage" data-component="graph3D">Графика 3D</button>
    `;